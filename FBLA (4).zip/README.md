# Schoolify- One stop to Simplify School
FBLA Mobile Applicaiton

Topic:

Develop a new mobile application for the students at your school. Your app 
should include a scheduling feature allowing students to input their schedule, 
information about extracurricular activities, a lunch menu, the ability to email 
teachers and staff, and a calendar that is updated with school information.

Topic Correlation:

Schoolify is a place where many of students resources are found all in one place. This optimizes user experience and reduces stress.

Features:

Scheduling feature 
Information about extracurricular activities
Lunch menu
Emailing toteachers and staff
Calendar updated with school information
Bug reporting system
Social media links
Motivational Quotes
Assignment task master


Runing the app
Download Anderoid Studios and install flutter (https://docs.flutter.dev/get-started/install)
Set up Anderoid Studio with Emulator
Connect physical device to Anderoid Studios using instructions in Anderoid Studio Emulator
Download Zip file from GitHub and open file in Anderoid Studio
Run Code and it will Appear on Physical device
Follow arrows on Schoolify
Enjoy!