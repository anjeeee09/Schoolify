import 'package:flutter/material.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50180Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50106Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50268Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50177Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50269Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50205Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50197Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50159Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50187Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50213Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50086Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50174Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50210Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50139Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50131Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50148Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50195Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50190Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50263Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50095Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50198Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50134Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50161Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50120Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50100Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50093Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50256Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50133Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50191Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50087Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50132Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50105Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50178Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50255Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50166Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50236Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50109Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50114Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50117Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50252Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50220Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50107Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50157Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50103Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50238Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50212Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50084Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50091Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50116Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50265Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50083Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50162Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50171Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50199Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50136Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50224Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50129Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50082Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50108Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50235Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50123Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50215Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50135Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50266Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50183Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50142Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50155Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50207Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50163Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50188Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50111Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50270Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50192Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50085Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50149Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50193Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50209Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50088Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50262Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50245Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50127Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50250Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50181Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50232Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50137Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50164Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50243Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50119Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50182Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50261Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50189Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50249Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50118Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50237Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50202Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50153Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50140Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50167Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50184Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50099Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50226Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50216Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50233Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50225Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50104Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50234Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50259Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50203Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50258Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50253Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50271Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50090Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50230Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50244Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50121Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50098Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50141Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50211Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50200Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50228Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50186Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50242Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50143Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50260Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50229Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50221Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50206Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50097Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50165Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedGroup_8125Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50144Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50240Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50145Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50241Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50110Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50156Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50112Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50247Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50231Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50147Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50217Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50227Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50257Widget.dart';
import 'package:flutterapp/helpers/transform/transform.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50246Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50115Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50152Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50102Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50208Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50124Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50194Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50185Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50172Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50154Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50173Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50122Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50126Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50096Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50101Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50175Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50151Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50169Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50214Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50204Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50251Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50170Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50168Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50094Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50272Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50179Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50125Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50150Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50146Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50218Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50176Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50128Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50254Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50138Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50222Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50267Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50239Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50219Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50223Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50130Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50264Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50092Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50160Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50158Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50201Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50196Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50113Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50248Widget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/generated/GeneratedPath_50089Widget.dart';

/* Group Group_8126
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedGroup_8126Widget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 374.8258056640625,
      height: 128.39096069335938,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.4804074027876882;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 180.069091796875;

                double percentHeight = 0.43221322687875185;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    55.492271423339844;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2906050434234913,
                      translateY: constraints.maxHeight * 0.4697943840375174,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50082Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.09791136703149543;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 36.69970703125;

                double percentHeight = 0.28721742809502476;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    36.876121520996094;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.00010323806012753971,
                      translateY: constraints.maxHeight * 0.04272821161294616,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50083Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.02111999942681708;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 7.91632080078125;

                double percentHeight = 0.22965066322170893;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    29.485069274902344;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.018558913922580574,
                      translateY: constraints.maxHeight * 0.06816357527664445,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50084Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04469996316648391;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 16.75469970703125;

                double percentHeight = 0.197682408253637;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    25.380634307861328;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04909881640983621,
                      translateY: constraints.maxHeight * 0.04614269517234494,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50085Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04379166364062994;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 16.41424560546875;

                double percentHeight = 0.16057749788156492;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 20.61669921875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.03947325140942749,
                      translateY: constraints.maxHeight * 0.16382390307847539,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50086Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0043346958369008;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.624755859375;

                double percentHeight = 0.012682146791803885;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.6282730102539062;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.014648568850178777,
                      translateY: constraints.maxHeight * 0.0936384553310285,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50087Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003497718504005604;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.31103515625;

                double percentHeight = 0.01021879007348266;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.3120002746582031;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.027088429423433345,
                      translateY: constraints.maxHeight * 0.12162541908172227,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50088Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0026679059576176826;
                double scaleX = (constraints.maxWidth * percentWidth) / 1.0;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.010270070113949417,
                      translateY: constraints.maxHeight * 0.1471703293111788,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50089Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0033311372177114826;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.24859619140625;

                double percentHeight = 0.009756804841322379;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.252685546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.01345937712602827,
                      translateY: constraints.maxHeight * 0.1982442540791017,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50090Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.006690770745395078;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.50787353515625;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.01683334022672641,
                      translateY: constraints.maxHeight * 0.2527483798279819,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50091Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004009512231104748;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.50286865234375;

                double percentHeight = 0.011701367801926023;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.502349853515625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04609497966666157,
                      translateY: constraints.maxHeight * 0.19332054151122563,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50092Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0046712779666856965;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.75091552734375;

                double percentHeight = 0.008232660623729087;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.0569992065429688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04778538077420729,
                      translateY: constraints.maxHeight * 0.23655343388521588,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50093Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0026679059576176826;
                double scaleX = (constraints.maxWidth * percentWidth) / 1.0;

                double percentHeight = 0.011184445873240927;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.4359817504882812;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.05081266590958756,
                      translateY: constraints.maxHeight * 0.2950111893779942,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50094Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337464049869519;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.62579345703125;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.06796777018491337,
                      translateY: constraints.maxHeight * 0.2895754572908038,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50095Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0039899719042667285;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.49554443359375;

                double percentHeight = 0.01661120506570417;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.1327285766601562;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.085292386795559,
                      translateY: constraints.maxHeight * 0.20067026335148908,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50096Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0040069068541930125;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.50189208984375;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.07923602532817164,
                      translateY: constraints.maxHeight * 0.16530282628356963,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50097Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0026679059576176826;
                double scaleX = (constraints.maxWidth * percentWidth) / 1.0;

                double percentHeight = 0.014152542775750128;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8170585632324219;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.080249028438666,
                      translateY: constraints.maxHeight * 0.10396343456263972,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50098Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.00467095229457173;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.75079345703125;

                double percentHeight = 0.009724716343622649;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.248565673828125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.061580525849735536,
                      translateY: constraints.maxHeight * 0.08331056436536677,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50099Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.06864565669013568;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 25.73016357421875;

                double percentHeight = 0.1587433431223059;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    20.381210327148438;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.13321210731677768,
                      translateY: constraints.maxHeight * 0.5274717353816095,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50100Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.012202934110343575;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 4.573974609375;

                double percentHeight = 0.07021884355431215;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.015464782714844;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.1679546455987205,
                      translateY: constraints.maxHeight * 0.48163153372322837,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50101Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.012144313129829514;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 4.552001953125;

                double percentHeight = 0.03381081810219117;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 4.34100341796875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.15843492403535106,
                      translateY: constraints.maxHeight * 0.4880737750216003,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50102Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.00812893880067336;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 3.04693603515625;

                double percentHeight = 0.0218389561492852;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.803924560546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.1621148560871212,
                      translateY: constraints.maxHeight * 0.4983214744545847,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50103Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.008920484873670158;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 3.3436279296875;

                double percentHeight = 0.034798846715623416;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 4.467857360839844;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.14145470568522553,
                      translateY: constraints.maxHeight * 0.5470438768609843,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50104Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.12611457210103783;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 47.27099609375;

                double percentHeight = 0.40793227663137327;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 52.37481689453125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.6558365490740653,
                      translateY: constraints.maxHeight * 0.5920677827917706,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50105Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.038968622468835624;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 14.6064453125;

                double percentHeight = 0.32263849455030347;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    41.423866271972656;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.6697792236172206,
                      translateY: constraints.maxHeight * 0.6593078629892456,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50106Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04167626042435728;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 15.621337890625;

                double percentHeight = 0.06273449858156956;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.054542541503906;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.695249388306352,
                      translateY: constraints.maxHeight * 0.700296521488003,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50107Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03982807117759454;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 14.9285888671875;

                double percentHeight = 0.04638142765291655;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 5.9549560546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7048475968491874,
                      translateY: constraints.maxHeight * 0.772922477754946,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50108Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03982807117759454;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 14.9285888671875;

                double percentHeight = 0.04638142765291655;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 5.9549560546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7013661619508802,
                      translateY: constraints.maxHeight * 0.75145669894928,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50109Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04948229532403235;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.5472412109375;

                double percentHeight = 0.14586667466898337;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    18.727962493896484;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7499691425672016,
                      translateY: constraints.maxHeight * 0.13214771286261487,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50110Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03398030269920305;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 12.7366943359375;

                double percentHeight = 0.10044068203507629;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    12.895675659179688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.757683663602852,
                      translateY: constraints.maxHeight * 0.1550211368122811,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50111Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0039471460212800675;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.4794921875;

                double percentHeight = 0.03282368083591725;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 4.214263916015625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7635008189025305,
                      translateY: constraints.maxHeight * 0.19252670773202063,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50112Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.006858003375917133;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.570556640625;

                double percentHeight = 0.06702829611265677;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.605827331542969;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7711339219096892,
                      translateY: constraints.maxHeight * 0.16915279235295447,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50113Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003046988298275273;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.14208984375;

                double percentHeight = 0.021832894988608582;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.8031463623046875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7806783945537201,
                      translateY: constraints.maxHeight * 0.19447266713650566,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50114Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04584421213890697;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 17.18359375;

                double percentHeight = 0.059836342719416985;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 7.682445526123047;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7931910428444463,
                      translateY: constraints.maxHeight * 0.2168545131283552,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50115Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.13013678554458727;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 48.77862548828125;

                double percentHeight = 0.30218932689027994;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    38.798377990722656;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.22532683639177442,
                      translateY: constraints.maxHeight * 0.6449544402755808,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50116Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0026679059576176826;
                double scaleX = (constraints.maxWidth * percentWidth) / 1.0;

                double percentHeight = 0.2341040118941365;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    30.056838989257812;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.28936504684956194,
                      translateY: constraints.maxHeight * 0.7017838233563856,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50117Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048397970020579224;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.14080810546875;

                double percentHeight = 0.018261801733491952;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3446502685546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.23318514166574122,
                      translateY: constraints.maxHeight * 0.6987519951320561,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50118Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048398947036921124;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.14117431640625;

                double percentHeight = 0.018261682887204176;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.344635009765625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2331841646493993,
                      translateY: constraints.maxHeight * 0.7310438982533161,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50119Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048398947036921124;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.14117431640625;

                double percentHeight = 0.01825502749508868;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.343780517578125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2331841646493993,
                      translateY: constraints.maxHeight * 0.7633427538824111,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50120Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048397970020579224;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.14080810546875;

                double percentHeight = 0.018261682887204176;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.344635009765625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.23318514166574122,
                      translateY: constraints.maxHeight * 0.795635786043405,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50121Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048398947036921124;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.14117431640625;

                double percentHeight = 0.018262752503794166;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3447723388671875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2331841646493993,
                      translateY: constraints.maxHeight * 0.82794212898863,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50122Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048397970020579224;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.14080810546875;

                double percentHeight = 0.018262752503794166;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3447723388671875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.23318514166574122,
                      translateY: constraints.maxHeight * 0.8602343292256095,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50123Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04840171524988984;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.1422119140625;

                double percentHeight = 0.018261801733491952;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3446502685546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2964560686230225,
                      translateY: constraints.maxHeight * 0.6987519951320561,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50124Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04840171524988984;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.1422119140625;

                double percentHeight = 0.018261682887204176;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.344635009765625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2964560686230225,
                      translateY: constraints.maxHeight * 0.7310438982533161,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50125Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04840171524988984;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.1422119140625;

                double percentHeight = 0.018253957878498685;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3436431884765625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2964560686230225,
                      translateY: constraints.maxHeight * 0.7633438234990011,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50126Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04840171524988984;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.1422119140625;

                double percentHeight = 0.018261682887204176;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.344635009765625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2964560686230225,
                      translateY: constraints.maxHeight * 0.795635786043405,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50127Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04840171524988984;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.1422119140625;

                double percentHeight = 0.018262752503794166;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3447723388671875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2964560686230225,
                      translateY: constraints.maxHeight * 0.82794212898863,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50128Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04840171524988984;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.1422119140625;

                double percentHeight = 0.018261682887204176;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.344635009765625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2964560686230225,
                      translateY: constraints.maxHeight * 0.8602353988421995,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50129Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.09500441774222597;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 35.610107421875;

                double percentHeight = 0.2422729709076172;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 31.10565948486328;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7762499051479969,
                      translateY: constraints.maxHeight * 0.3632742984206517,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50130Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.056528537181822415;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 21.1883544921875;

                double percentHeight = 0.14441267947275033;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    18.541282653808594;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7923009809569744,
                      translateY: constraints.maxHeight * 0.40282063837095017,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50131Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.00473559820919418;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.7750244140625;

                double percentHeight = 0.0243881495989532;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    3.1312179565429688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7919619562863348,
                      translateY: constraints.maxHeight * 0.5628797881683767,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50132Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004057548867914881;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.5208740234375;

                double percentHeight = 0.01813166504837638;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.32794189453125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8106161293022508,
                      translateY: constraints.maxHeight * 0.5440723631277016,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50133Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003924348973302377;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.470947265625;

                double percentHeight = 0.018924369787847492;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.429718017578125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8294080616223747,
                      translateY: constraints.maxHeight * 0.5154799666755009,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50134Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004438259569142307;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.66357421875;

                double percentHeight = 0.01812732715887253;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3273849487304688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8460502323182025,
                      translateY: constraints.maxHeight * 0.49002267587170784,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50135Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.006205030787413294;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.3258056640625;

                double percentHeight = 0.011823720055192216;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.5180587768554688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8605201700138704,
                      translateY: constraints.maxHeight * 0.4504736618799344,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50136Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.006341487403165468;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.376953125;

                double percentHeight = 0.016124945479265483;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.0702972412109375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8481758942060651,
                      translateY: constraints.maxHeight * 0.406222316242841,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50137Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004463336321917766;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.6729736328125;

                double percentHeight = 0.01691735310301715;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.1720352172851562;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8331526395887673,
                      translateY: constraints.maxHeight * 0.37214534187917375,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50138Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0029939037436986517;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.1221923828125;

                double percentHeight = 0.019729909926398493;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.53314208984375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8149101161249057,
                      translateY: constraints.maxHeight * 0.3658398926580329,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50139Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004988971113860508;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.8699951171875;

                double percentHeight = 0.014599137413643316;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8743972778320312;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7949190590811552,
                      translateY: constraints.maxHeight * 0.38817295224875004,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50140Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.005811618873741155;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.1783447265625;

                double percentHeight = 0.008370641163837927;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.0747146606445312;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7819016190137802,
                      translateY: constraints.maxHeight * 0.4394629692794231,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50141Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.007149805590031567;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.679931640625;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7767993140042592,
                      translateY: constraints.maxHeight * 0.49943672801908195,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50142Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.005814875594880825;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.1795654296875;

                double percentHeight = 0.009905303277899463;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.2717514038085938;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7798736587601076,
                      translateY: constraints.maxHeight * 0.5542765053962156,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50143Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04369982410449125;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 16.37982177734375;

                double percentHeight = 0.16659349696882544;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 21.38909912109375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.2352933800955066,
                      translateY: constraints.maxHeight * 0.3315538676741663,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50144Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03254848525014712;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 12.20001220703125;

                double percentHeight = 0.0852498089545924;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    10.945304870605469;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.23067893191270816,
                      translateY: constraints.maxHeight * 0.48219718262990197,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50145Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.014695791306703994;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 5.50836181640625;

                double percentHeight = 0.01795131580667512;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.3047866821289062;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.23661837709118136,
                      translateY: constraints.maxHeight * 0.4996668144322178,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50146Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.012404199476775181;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 4.6494140625;

                double percentHeight = 0.01567695439749092;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.0127792358398438;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.24198952443078214,
                      translateY: constraints.maxHeight * 0.529412079298997,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50147Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0276593326392175;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 10.367431640625;

                double percentHeight = 0.10379636639359752;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    13.326515197753906;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.24277390571727167,
                      translateY: constraints.maxHeight * 0.39350362421754576,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50148Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0628560206840873;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 23.56005859375;

                double percentHeight = 0.17689313222956823;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 22.71147918701172;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8394670962064735,
                      translateY: constraints.maxHeight * 0.025093413182192548,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50149Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04551202658266063;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 17.05908203125;

                double percentHeight = 0.12817313646049608;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 16.45627212524414;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8481791509272048,
                      translateY: constraints.maxHeight * 0.04941269135737911,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50150Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.06286741920807615;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 23.5643310546875;

                double percentHeight = 0.17691740658384664;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    22.714595794677734;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9125515009739225,
                      translateY: constraints.maxHeight * 0.10342624934188868,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50151Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.045501930747127654;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 17.0552978515625;

                double percentHeight = 0.12815958798368954;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    16.454532623291016;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9212710461532749,
                      translateY: constraints.maxHeight * 0.12776715754145063,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50152Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.017169759520454325;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 6.4356689453125;

                double percentHeight = 0.023453215564585232;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 3.011180877685547;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.900880389425687,
                      translateY: constraints.maxHeight * 0.12215481987062393,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50153Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.016110673805833635;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 6.0386962890625;

                double percentHeight = 0.022594016327103016;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.900867462158203;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.899647069130094,
                      translateY: constraints.maxHeight * 0.14028390001224117,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50154Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0160803862992347;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 6.02734375;

                double percentHeight = 0.02412392458965348;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    3.0972938537597656;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8558643614725981,
                      translateY: constraints.maxHeight * 0.07306556868542932,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50155Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.021617463580901674;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 8.102783203125;

                double percentHeight = 0.031850329739025435;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 4.08929443359375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8607067801351734,
                      translateY: constraints.maxHeight * 0.09207782530308775,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50156Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.007286913550011675;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.7313232421875;

                double percentHeight = 0.012430549200580445;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.5959701538085938;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8712624646930719,
                      translateY: constraints.maxHeight * 0.1256037985650499,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50157Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.020877536537968647;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 7.825439453125;

                double percentHeight = 0.030596352845120706;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 3.928295135498047;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9276014607045656,
                      translateY: constraints.maxHeight * 0.15748740526465285,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50158Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.012951654300353712;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 4.8546142578125;

                double percentHeight = 0.019993154453824057;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.5669403076171875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9396617504289916,
                      translateY: constraints.maxHeight * 0.19434978007494447,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50159Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0026679059576176826;
                double scaleX = (constraints.maxWidth * percentWidth) / 1.0;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9506202913918672,
                      translateY: constraints.maxHeight * 0.2162192797201883,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50160Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04146994714015918;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 15.54400634765625;

                double percentHeight = 0.07606308004416328;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.765811920166016;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.1803340939948342,
                      translateY: constraints.maxHeight * 0.16881179264175095,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50161Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03451293944159608;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 12.93634033203125;

                double percentHeight = 0.09156699424665121;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 11.75637435913086;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.18826551265838656,
                      translateY: constraints.maxHeight * 0.1660120712174495,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50162Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04962331134938007;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.60009765625;

                double percentHeight = 0.03817063474613839;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 4.900764465332031;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.1731054757532226,
                      translateY: constraints.maxHeight * 0.16188647089513836,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50163Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.043125012823339484;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 16.16436767578125;

                double percentHeight = 0.15991712848353326;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 20.53191375732422;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.13593554036982675,
                      translateY: constraints.maxHeight * 0.25069227962629975,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50164Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.17285373120912612;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 64.7900390625;

                double percentHeight = 0.17461300677542688;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    22.418731689453125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04326668019291513,
                      translateY: constraints.maxHeight * 0.7286074305076043,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50165Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.15270195497713293;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 57.23663330078125;

                double percentHeight = 0.15021053619879657;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    19.285675048828125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04431697276045871,
                      translateY: constraints.maxHeight * 0.7528077435487264,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50166Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.020789442231140574;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 7.79241943359375;

                double percentHeight = 0.07233484228503381;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.287139892578125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.07527601525838988,
                      translateY: constraints.maxHeight * 0.8123922806959163,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50167Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.02700212631323209;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 10.12109375;

                double percentHeight = 0.0692569611241908;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.8919677734375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.10594602375517534,
                      translateY: constraints.maxHeight * 0.784635611339362,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50168Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.016805169588868265;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 6.29901123046875;

                double percentHeight = 0.055825072525947116;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    7.1674346923828125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.13828982408169418,
                      translateY: constraints.maxHeight * 0.7680954169306045,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50169Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.010505368216290575;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 3.93768310546875;

                double percentHeight = 0.03942987058827724;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 5.06243896484375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.16664658355297204,
                      translateY: constraints.maxHeight * 0.7585790381294545,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50170Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.12846690178022147,
                      translateY: constraints.maxHeight * 0.7873576667146014,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50171Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.1327568177014518,
                      translateY: constraints.maxHeight * 0.7738753872903403,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50172Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.15947593494764659,
                      translateY: constraints.maxHeight * 0.8008399461388623,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50173Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.16409412835975565,
                      translateY: constraints.maxHeight * 0.8085429682811143,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50174Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.20103934998451428,
                      translateY: constraints.maxHeight * 0.7440213186471014,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50175Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.10482847989609757;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 39.29241943359375;

                double percentHeight = 0.45840451235585433;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 58.85499572753906;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.002710731840604343,
                      translateY: constraints.maxHeight * 0.28623979853177295,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50176Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.08847094662787695;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 33.16119384765625;

                double percentHeight = 0.3945852442826022;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 50.66117858886719;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.004905110544514004,
                      translateY: constraints.maxHeight * 0.3354110239439616,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50177Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.029049626893742634;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 10.8885498046875;

                double percentHeight = 0.07503271244071055;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.633522033691406;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.012531211601222312,
                      translateY: constraints.maxHeight * 0.5907052101024098,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50178Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03197448814928028;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.98486328125;

                double percentHeight = 0.09129177595573214;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    11.721038818359375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.0296796395982118,
                      translateY: constraints.maxHeight * 0.49539779635213205,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50179Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.031077098639244207;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.64849853515625;

                double percentHeight = 0.07627911288376953;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.793548583984375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04673590238694862,
                      translateY: constraints.maxHeight * 0.4355026544318375,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50180Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.02943733954542035;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.03387451171875;

                double percentHeight = 0.06370315525009418;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.178909301757812;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.06458892200250572,
                      translateY: constraints.maxHeight * 0.3690493960825887,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50181Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04957413486017105,
                      translateY: constraints.maxHeight * 0.40277452601129277,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50182Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.05419232827228013,
                      translateY: constraints.maxHeight * 0.3882953045020162,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50183Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.055510323317504585,
                      translateY: constraints.maxHeight * 0.4085459394383087,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50184Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.07596236923857534,
                      translateY: constraints.maxHeight * 0.46248278214405836,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50185Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.08058056265068442,
                      translateY: constraints.maxHeight * 0.44414812763615924,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50186Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.08289104346322332,
                      translateY: constraints.maxHeight * 0.46440654700430106,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50187Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.0396764708085429,
                      translateY: constraints.maxHeight * 0.6059430868897094,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50188Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.04660498219713389,
                      translateY: constraints.maxHeight * 0.6001638296077003,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50189Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.01691654945184498,
                      translateY: constraints.maxHeight * 0.5414524561368064,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50190Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.01823454449706944,
                      translateY: constraints.maxHeight * 0.5192702719084218,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50191Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.003114890934037393;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16754150390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.09674546086349356,
                      translateY: constraints.maxHeight * 0.3507692920207791,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50192Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.12396253077194387;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 46.46435546875;

                double percentHeight = 0.3623262615830563;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 46.51941680908203;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: 0,
                      translateY: constraints.maxHeight * 0.5386530912513682,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50193Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.10346472791886074;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 38.78125;

                double percentHeight = 0.34316948787946133;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 44.05986022949219;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.0010126774383803934,
                      translateY: constraints.maxHeight * 0.5662333332937179,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50194Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04588492115315285;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 17.1988525390625;

                double percentHeight = 0.12971062117389232;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    16.653671264648438;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.054637033543902064,
                      translateY: constraints.maxHeight * 0.6033506928144345,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50195Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.048931583779314156;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.3408203125;

                double percentHeight = 0.1326325760051722;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    17.028823852539062;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.018678435588406463,
                      translateY: constraints.maxHeight * 0.7150640640914261,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50196Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.043126641183909326,
                      translateY: constraints.maxHeight * 0.6738683753593615,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50197Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.043126641183909326,
                      translateY: constraints.maxHeight * 0.6372691856533516,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50198Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.06555844788578549,
                      translateY: constraints.maxHeight * 0.6430484429353607,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50199Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.09854707899795902,
                      translateY: constraints.maxHeight * 0.683495162361856,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50200Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.10844230050873241,
                      translateY: constraints.maxHeight * 0.6950536769258744,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50201Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.05500162347548813,
                      translateY: constraints.maxHeight * 0.7855818654826408,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50202Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.08205146075341638,
                      translateY: constraints.maxHeight * 0.8241048200488934,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50203Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.016076803905981065,
                      translateY: constraints.maxHeight * 0.6565307223596217,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50204Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788845599827785;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.79498291015625;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.008161180339956093,
                      translateY: constraints.maxHeight * 0.7952086524851353,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50205Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.17285373120912612;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 64.7900390625;

                double percentHeight = 0.17461300677542688;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    22.418731689453125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7838745406801922,
                      translateY: constraints.maxHeight * 0.7286074305076043,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50206Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.1527021178131899;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 57.2366943359375;

                double percentHeight = 0.15019199617790338;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    19.283294677734375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8029914937700553,
                      translateY: constraints.maxHeight * 0.7528104770133452,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50207Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.020782440280690283;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 7.789794921875;

                double percentHeight = 0.07232652304488943;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.28607177734375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9039579909026751,
                      translateY: constraints.maxHeight * 0.8123925183884919,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50208Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.02700668572282763;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 10.122802734375;

                double percentHeight = 0.06926480497918407;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.892974853515625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8670528269479345,
                      translateY: constraints.maxHeight * 0.7846199236293755,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50209Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.016807937801836988;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 6.300048828125;

                double percentHeight = 0.05581651559322719;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    7.1663360595703125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8449172190337113,
                      translateY: constraints.maxHeight * 0.7681051623262022,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50210Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.010508462101373262;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 3.9388427734375;

                double percentHeight = 0.03940752748617521;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 5.0595703125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8228412091163441,
                      translateY: constraints.maxHeight * 0.7586012623852688,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50211Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8684157647448864,
                      translateY: constraints.maxHeight * 0.7873576667146014,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50212Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.864126011659713,
                      translateY: constraints.maxHeight * 0.7738753872903403,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50213Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8374065687414043,
                      translateY: constraints.maxHeight * 0.8008399461388623,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50214Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8327885381653523,
                      translateY: constraints.maxHeight * 0.8085429682811143,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50215Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.7958436422127075,
                      translateY: constraints.maxHeight * 0.7440213186471014,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50216Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.10482864273215456;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 39.29248046875;

                double percentHeight = 0.45840451235585433;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 58.85499572753906;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8924585085585003,
                      translateY: constraints.maxHeight * 0.28623979853177295,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50217Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.088470458119706;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 33.1610107421875;

                double percentHeight = 0.39457229003723454;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    50.659515380859375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9066200347622414,
                      translateY: constraints.maxHeight * 0.33541423279373156,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50218Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.029042787779349325;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 10.885986328125;

                double percentHeight = 0.07506355305238863;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.637481689453125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9584181844886932,
                      translateY: constraints.maxHeight * 0.5906431723401904,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50219Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.031988166378066896;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.989990234375;

                double percentHeight = 0.09136177641923265;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    11.730026245117188;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9383323568597783,
                      translateY: constraints.maxHeight * 0.49531222702493277,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50220Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.031079866852212926;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.6495361328125;

                double percentHeight = 0.07629206712913719;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.795211791992188;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9221819510560407,
                      translateY: constraints.maxHeight * 0.4355416360142283,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50221Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.029336544026147562;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 10.99609375;

                double percentHeight = 0.06390448086158805;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.204757690429688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.905962502764142,
                      translateY: constraints.maxHeight * 0.3690104145001979,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50222Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9473085316649368,
                      translateY: constraints.maxHeight * 0.40277452601129277,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50223Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031150537700943767;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.1676025390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9426905010888847,
                      translateY: constraints.maxHeight * 0.3882953045020162,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50224Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9413721803715462,
                      translateY: constraints.maxHeight * 0.4085459394383087,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50225Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031150537700943767;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.1676025390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9209202972865325,
                      translateY: constraints.maxHeight * 0.46248278214405836,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50226Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9163019410383665,
                      translateY: constraints.maxHeight * 0.44414812763615924,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50227Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9139916230618845,
                      translateY: constraints.maxHeight * 0.46440654700430106,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50228Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031153794422083434;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.167724609375;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9572063585526219,
                      translateY: constraints.maxHeight * 0.6059430868897094,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50229Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9502780100000879,
                      translateY: constraints.maxHeight * 0.6001638296077003,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50230Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031150537700943767;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.1676025390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9799662799093198,
                      translateY: constraints.maxHeight * 0.5414524561368064,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50231Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031147280979804096;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.16748046875;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9786486105362093,
                      translateY: constraints.maxHeight * 0.5192702719084218,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50232Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0031150537700943767;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.1676025390625;

                double percentHeight = 0.009626787002494584;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.235992431640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9001375313337283,
                      translateY: constraints.maxHeight * 0.3507692920207791,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50233Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.1239651361488556;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 46.46533203125;

                double percentHeight = 0.3623262615830563;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 46.51941680908203;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8760348638511444,
                      translateY: constraints.maxHeight * 0.5386530912513682,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50234Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.10346570493520264;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 38.7816162109375;

                double percentHeight = 0.34314940285682705;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    44.057281494140625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8955221061345879,
                      translateY: constraints.maxHeight * 0.5662384436840923,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50235Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04588524682526682;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 17.198974609375;

                double percentHeight = 0.12972036656949001;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    16.654922485351562;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8994754399260334,
                      translateY: constraints.maxHeight * 0.6033491478126934,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50236Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04893418915622589;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 18.341796875;

                double percentHeight = 0.1326341210069133;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    17.029022216796875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9323992622875275,
                      translateY: constraints.maxHeight * 0.7150627567822605,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50237Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9520822335114651,
                      translateY: constraints.maxHeight * 0.6738683753593615,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50238Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9520822335114651,
                      translateY: constraints.maxHeight * 0.6372691856533516,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50239Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.929650589645646,
                      translateY: constraints.maxHeight * 0.6430484429353607,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50240Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8966619585334724,
                      translateY: constraints.maxHeight * 0.683495162361856,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50241Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.886766737022699,
                      translateY: constraints.maxHeight * 0.6950536769258744,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50242Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9402075768920003,
                      translateY: constraints.maxHeight * 0.7855818654826408,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50243Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.913157576778015,
                      translateY: constraints.maxHeight * 0.8241048200488934,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50244Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9791322336254503,
                      translateY: constraints.maxHeight * 0.6565307223596217,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50245Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004788682763770801;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.794921875;

                double percentHeight = 0.014448024358735143;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8549957275390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.9870480200275323,
                      translateY: constraints.maxHeight * 0.7952086524851353,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50246Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.06759064187693958;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 25.334716796875;

                double percentHeight = 0.212707639320532;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    27.309738159179688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.42737951515889705,
                      translateY: constraints.maxHeight * 0.6985605931855916,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50247Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.05681122057674577;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 21.2943115234375;

                double percentHeight = 0.18946665351434416;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 24.3258056640625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.4286470310264566,
                      translateY: constraints.maxHeight * 0.7202607368707534,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50248Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0310218972159268;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.6278076171875;

                double percentHeight = 0.07123182988817753;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.145523071289062;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.4536807950828722,
                      translateY: constraints.maxHeight * 0.7499801526699412,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50249Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.03331104650500086;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 12.48583984375;

                double percentHeight = 0.081783478702151;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    10.500259399414062;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.4372467288678693,
                      translateY: constraints.maxHeight * 0.7895243533870597,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50250Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.05684085673911677;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 21.305419921875;

                double percentHeight = 0.29180400345605007;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    37.464996337890625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.37555694002389783,
                      translateY: constraints.maxHeight * 0.6279227570437224,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50251Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.04486263638741043;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 16.815673828125;

                double percentHeight = 0.2532765921540058;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 32.51842498779297;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.38479234983177407,
                      translateY: constraints.maxHeight * 0.6652139292603126,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50252Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.015798028576425312;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 5.9215087890625;

                double percentHeight = 0.049944082821601024;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    6.4123687744140625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.38451455151856023,
                      translateY: constraints.maxHeight * 0.6951733551376656,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50253Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.022386701114091734;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 8.39111328125;

                double percentHeight = 0.05673864394008721;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 7.28472900390625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.3881457955892923,
                      translateY: constraints.maxHeight * 0.741349891790455,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50254Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.024354086354566394;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 9.1285400390625;

                double percentHeight = 0.05090650006001737;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    6.5359344482421875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.3973984660192088,
                      translateY: constraints.maxHeight * 0.8049580888566156,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50255Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0668601593253116;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 25.0609130859375;

                double percentHeight = 0.18201451588558906;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 23.3690185546875;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.547422907711362,
                      translateY: constraints.maxHeight * 0.7378956244362229,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50256Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.05140766886180527;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 19.2689208984375;

                double percentHeight = 0.13838842056848932;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 17.767822265625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.5555516836759784,
                      translateY: constraints.maxHeight * 0.7676882495486812,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50257Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.0026679059576176826;
                double scaleX = (constraints.maxWidth * percentWidth) / 1.0;

                double percentHeight = 0.06612619336528713;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 8.490005493164062;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.5809003726666,
                      translateY: constraints.maxHeight * 0.6582596981541983,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50258Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.006808175542480182;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.5518798828125;

                double percentHeight = 0.01988244913675999;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    2.5527267456054688;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.5554728710243984,
                      translateY: constraints.maxHeight * 0.7109866262272365,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50259Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.007843487192781282;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.93994140625;

                double percentHeight = 0.022898589651102953;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 2.939971923828125;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.6026748102064338,
                      translateY: constraints.maxHeight * 0.7143152136321446,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50260Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.015238523884630002;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 5.7117919921875;

                double percentHeight = 0.014522897520034514;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.8646087646484375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.5282535214111503,
                      translateY: constraints.maxHeight * 0.7829696240773071,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50261Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.015264903325861329;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 5.7216796875;

                double percentHeight = 0.010108471006853866;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.2978363037109375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.6210733306128856,
                      translateY: constraints.maxHeight * 0.7906165507717283,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50262Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.007544845864273541;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 2.8280029296875;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.6217966483780063,
                      translateY: constraints.maxHeight * 0.8540445768656193,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50263Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.009017209491518359;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 3.3798828125;

                double percentHeight = 0.007788710315738933;
                double scaleY = (constraints.maxHeight * percentHeight) / 1.0;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.5344790695417435,
                      translateY: constraints.maxHeight * 0.8551392700223313,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50264Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.02953878640892107;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 11.0718994140625;

                double percentHeight = 0.10369879359133277;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    13.313987731933594;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.11492496677330258,
                      translateY: 0,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50265Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.022584872595440654;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 8.46539306640625;

                double percentHeight = 0.07611088596342148;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 9.771949768066406;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.3064299399493189,
                      translateY: constraints.maxHeight * 0.5020575263571355,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50266Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337789721983487;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.62591552734375;

                double percentHeight = 0.0131083890029153;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.6829986572265625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.1894680569392097,
                      translateY: constraints.maxHeight * 0.3906708635252424,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50267Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337789721983487;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.62591552734375;

                double percentHeight = 0.0131083890029153;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.6829986572265625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.19349922636589328,
                      translateY: constraints.maxHeight * 0.37101214252522213,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50268Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337789721983487;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.62591552734375;

                double percentHeight = 0.0131083890029153;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.6829986572265625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.19664212510173182,
                      translateY: constraints.maxHeight * 0.393287858782087,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50269Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337301213812536;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.625732421875;

                double percentHeight = 0.013108270156627523;
                double scaleY =
                    (constraints.maxHeight * percentHeight) / 1.6829833984375;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.835405639273191,
                      translateY: constraints.maxHeight * 0.636023082326012,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50270Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337301213812536;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.625732421875;

                double percentHeight = 0.0131083890029153;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.6829986572265625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.8394556976824846,
                      translateY: constraints.maxHeight * 0.6163332235985943,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50271Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                double percentWidth = 0.004337626885926503;
                double scaleX =
                    (constraints.maxWidth * percentWidth) / 1.6258544921875;

                double percentHeight = 0.0131083890029153;
                double scaleY = (constraints.maxHeight * percentHeight) /
                    1.6829986572265625;

                return Stack(children: [
                  TransformHelper.translateAndScale(
                      translateX: constraints.maxWidth * 0.842590291779417,
                      translateY: constraints.maxHeight * 0.6386088210091714,
                      translateZ: 0,
                      scaleX: scaleX,
                      scaleY: scaleY,
                      scaleZ: 1,
                      child: GeneratedPath_50272Widget())
                ]);
              }),
            ),
            Positioned(
              left: 0.0,
              top: 0.0,
              right: 0.0,
              bottom: 0.0,
              width: null,
              height: null,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                final double width = constraints.maxWidth * 0.1281369959287729;

                final double height =
                    constraints.maxHeight * 0.19505266673242827;

                return Stack(children: [
                  TransformHelper.translate(
                      x: constraints.maxWidth * 0.4605059055752786,
                      y: constraints.maxHeight * 0.3077755778009396,
                      z: 0,
                      child: Container(
                        width: width,
                        height: height,
                        child: GeneratedGroup_8125Widget(),
                      ))
                ]);
              }),
            )
          ]),
    );
  }
}
