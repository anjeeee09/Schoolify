import 'package:flutter/material.dart';
import 'package:flutterapp/fblaapp/generatedquiz_swipe_bg2widget/GeneratedQuiz_swipe_bg2Widget.dart';
import 'package:flutterapp/fblaapp/generated01_splashwidget/Generated01_splashWidget.dart';
import 'package:flutterapp/fblaapp/generated02_loginwidget/Generated02_loginWidget.dart';
import 'package:flutterapp/fblaapp/generated02_login_v2widget/Generated02_login_v2Widget.dart';
import 'package:flutterapp/fblaapp/generated03_dashboardwidget/Generated03_dashboardWidget.dart';
import 'package:flutterapp/fblaapp/generated05_attendancewidget/Generated05_attendanceWidget.dart';
import 'package:flutterapp/fblaapp/generated06_holidaywidget/Generated06_holidayWidget.dart';
import 'package:flutterapp/fblaapp/generated09_quizwidget/Generated09_quizWidget.dart';
import 'package:flutterapp/fblaapp/generated09_quizwidget1/Generated09_quizWidget1.dart';
import 'package:flutterapp/fblaapp/generated09_quizwidget2/Generated09_quizWidget2.dart';
import 'package:flutterapp/fblaapp/generated10_assignmentwidget/Generated10_AssignmentWidget.dart';
import 'package:flutterapp/fblaapp/generated10_assignmentwidget1/Generated10_AssignmentWidget1.dart';
import 'package:flutterapp/fblaapp/generatedarrow1widget/GeneratedArrow1Widget.dart';
import 'package:flutterapp/fblaapp/generated11_timetablewidget/Generated11_timetableWidget.dart';
import 'package:flutterapp/fblaapp/generated11_timetablewidget1/Generated11_timetableWidget1.dart';
import 'package:flutterapp/fblaapp/generated11_timetablewidget2/Generated11_timetableWidget2.dart';
import 'package:flutterapp/fblaapp/generated11_timetablewidget3/Generated11_timetableWidget3.dart';
import 'package:flutterapp/fblaapp/generated14_ask_doubtswidget/Generated14_ask_doubtsWidget.dart';
import 'package:flutterapp/fblaapp/generated16_leave_applicationwidget/Generated16_leave_applicationWidget.dart';
import 'package:flutterapp/fblaapp/generated17_change_passwordwidget/Generated17_change_passwordWidget.dart';
import 'package:flutterapp/fblaapp/generated20_supportwidget/Generated20_supportWidget.dart';
import 'package:flutterapp/fblaapp/generatedback_arrowwidget18/GeneratedBack_ArrowWidget18.dart';
import 'package:flutterapp/fblaapp/generatediphone13promax2widget/GeneratedIPhone13ProMax2Widget.dart';
import 'package:flutterapp/fblaapp/generatedback_arrowwidget22/GeneratedBack_ArrowWidget22.dart';
import 'package:flutterapp/fblaapp/generatedbasicwebtoggleswitchondefaultwidget/GeneratedBasicWebToggleSwitchOnDefaultWidget.dart';
import 'package:flutterapp/fblaapp/generatedbars_status_bar_iphone_lightwidget/GeneratedBars_Status_Bar_iPhone_LightWidget.dart';
import 'package:flutterapp/fblaapp/generatedbars_home_indicator_iphone_on_light__portraitwidget/GeneratedBars_Home_Indicator_iPhone_On_Light__PortraitWidget.dart';
import 'package:flutterapp/fblaapp/generatedvectorwidget53/GeneratedVectorWidget53.dart';
import 'package:flutterapp/fblaapp/generatedic_backwidget40/GeneratedIc_backWidget40.dart';
import 'package:flutterapp/fblaapp/generatedbuttonwidget9/GeneratedButtonWidget9.dart';
import 'package:flutterapp/fblaapp/generatedicon_viewwidget2/GeneratedIcon_viewWidget2.dart';
import 'package:flutterapp/fblaapp/generatedic_sharewidget/GeneratedIc_shareWidget.dart';
import 'package:flutterapp/fblaapp/generatedic_downloadwidget/GeneratedIc_downloadWidget.dart';
import 'package:flutterapp/fblaapp/generatedic_timewidget/GeneratedIc_timeWidget.dart';
import 'package:flutterapp/fblaapp/generatedic_camerawidget/GeneratedIc_cameraWidget.dart';
import 'package:flutterapp/fblaapp/generatedic_lockwidget/GeneratedIc_lockWidget.dart';
import 'package:flutterapp/fblaapp/generatedic_calenderwidget2/GeneratedIc_CalenderWidget2.dart';
import 'package:flutterapp/fblaapp/generated0_fontfamilywidget/Generated0_fontfamilyWidget.dart';
import 'package:flutterapp/fblaapp/generated0_colorpalettewidget/Generated0_colorPaletteWidget.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget/GeneratedUIKitWidget.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget1/GeneratedUIKitWidget1.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget2/GeneratedUIKitWidget2.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget3/GeneratedUIKitWidget3.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget4/GeneratedUIKitWidget4.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget5/GeneratedUIKitWidget5.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget6/GeneratedUIKitWidget6.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget7/GeneratedUIKitWidget7.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget8/GeneratedUIKitWidget8.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget9/GeneratedUIKitWidget9.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget10/GeneratedUIKitWidget10.dart';
import 'package:flutterapp/fblaapp/generateduikitwidget11/GeneratedUIKitWidget11.dart';
import 'package:flutterapp/fblaapp/generatedhttpssyaluiuxblogspotcomwidget/GeneratedhttpssyaluiuxblogspotcomWidget.dart';
import 'package:flutterapp/fblaapp/generatedhttpsakshaysyalwordpresscomcategoryfreebiewidget/GeneratedhttpsakshaysyalwordpresscomcategoryfreebieWidget.dart';
import 'package:flutterapp/fblaapp/generateduiresourcesforyourbusinesswidget/GeneratedUIresourcesforyourbusinessWidget.dart';
import 'package:flutterapp/fblaapp/generatedgetmorefreebieitemswidget/GeneratedGetmorefreebieitemsWidget.dart';

void main() {
  runApp(FBLAApp());
}

class FBLAApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //this is old flutter introcode that comes with set up
      title: 'Flutter Demo',
      theme: ThemeData(
        //main theme color of the app --in the future make customizable by school and color of school
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/Generated01_splashWidget',
      routes: {
        //main intro screen widget
        //widget connects to second screen flow
        '/GeneratedQuiz_swipe_bg2Widget': (context) => GeneratedQuiz_swipe_bg2Widget(),
        '/Generated01_splashWidget': (context) => Generated01_splashWidget(),
        //log in screen widget
        '/Generated02_loginWidget': (context) => Generated02_loginWidget(),
        '/Generated02_login_v2Widget': (context) => Generated02_login_v2Widget(),
        '/Generated03_dashboardWidget': (context) => Generated03_dashboardWidget(),
        '/Generated05_attendanceWidget': (context) => Generated05_attendanceWidget(),
        '/Generated06_holidayWidget': (context) => Generated06_holidayWidget(),
        '/Generated09_quizWidget': (context) => Generated09_quizWidget(),
        '/Generated09_quizWidget1': (context) => Generated09_quizWidget1(),
        '/Generated09_quizWidget2': (context) => Generated09_quizWidget2(),
        '/Generated10_AssignmentWidget': (context) => Generated10_AssignmentWidget(),
        '/Generated10_AssignmentWidget1': (context) => Generated10_AssignmentWidget1(),
        '/GeneratedArrow1Widget': (context) => GeneratedArrow1Widget(),
        '/Generated11_timetableWidget': (context) => Generated11_timetableWidget(),
        '/Generated11_timetableWidget1': (context) => Generated11_timetableWidget1(),
        '/Generated11_timetableWidget2': (context) => Generated11_timetableWidget2(),
        '/Generated11_timetableWidget3': (context) => Generated11_timetableWidget3(),
        '/Generated14_ask_doubtsWidget': (context) => Generated14_ask_doubtsWidget(),
        '/Generated16_leave_applicationWidget': (context) => Generated16_leave_applicationWidget(),
        '/Generated17_change_passwordWidget': (context) => Generated17_change_passwordWidget(),
        '/Generated20_supportWidget': (context) => Generated20_supportWidget(),
        '/GeneratedBack_ArrowWidget18': (context) => GeneratedBack_ArrowWidget18(),
        '/GeneratedIPhone13ProMax2Widget': (context) => GeneratedIPhone13ProMax2Widget(),
        '/GeneratedBack_ArrowWidget22': (context) => GeneratedBack_ArrowWidget22(),
        '/GeneratedBasicWebToggleSwitchOnDefaultWidget': (context) => GeneratedBasicWebToggleSwitchOnDefaultWidget(),
        '/GeneratedBars_Status_Bar_iPhone_LightWidget': (context) => GeneratedBars_Status_Bar_iPhone_LightWidget(),
        '/GeneratedBars_Home_Indicator_iPhone_On_Light__PortraitWidget': (context) => GeneratedBars_Home_Indicator_iPhone_On_Light__PortraitWidget(),
        '/GeneratedVectorWidget53': (context) => GeneratedVectorWidget53(),
        '/GeneratedIc_backWidget40': (context) => GeneratedIc_backWidget40(),
        '/GeneratedButtonWidget9': (context) => GeneratedButtonWidget9(),
        '/GeneratedIcon_viewWidget2': (context) => GeneratedIcon_viewWidget2(),
        '/GeneratedIc_shareWidget': (context) => GeneratedIc_shareWidget(),
        '/GeneratedIc_downloadWidget': (context) => GeneratedIc_downloadWidget(),
        '/GeneratedIc_timeWidget': (context) => GeneratedIc_timeWidget(),
        '/GeneratedIc_cameraWidget': (context) => GeneratedIc_cameraWidget(),
        '/GeneratedIc_lockWidget': (context) => GeneratedIc_lockWidget(),
        '/GeneratedIc_CalenderWidget2': (context) => GeneratedIc_CalenderWidget2(),
        '/Generated0_fontfamilyWidget': (context) => Generated0_fontfamilyWidget(),
        '/Generated0_colorPaletteWidget': (context) => Generated0_colorPaletteWidget(),
        '/GeneratedUIKitWidget': (context) => GeneratedUIKitWidget(),
        '/GeneratedUIKitWidget1': (context) => GeneratedUIKitWidget1(),
        '/GeneratedUIKitWidget2': (context) => GeneratedUIKitWidget2(),
        '/GeneratedUIKitWidget3': (context) => GeneratedUIKitWidget3(),
        '/GeneratedUIKitWidget4': (context) => GeneratedUIKitWidget4(),
        '/GeneratedUIKitWidget5': (context) => GeneratedUIKitWidget5(),
        '/GeneratedUIKitWidget6': (context) => GeneratedUIKitWidget6(),
        '/GeneratedUIKitWidget7': (context) => GeneratedUIKitWidget7(),
        '/GeneratedUIKitWidget8': (context) => GeneratedUIKitWidget8(),
        '/GeneratedUIKitWidget9': (context) => GeneratedUIKitWidget9(),
        '/GeneratedUIKitWidget10': (context) => GeneratedUIKitWidget10(),
        '/GeneratedUIKitWidget11': (context) => GeneratedUIKitWidget11(),
        '/GeneratedhttpssyaluiuxblogspotcomWidget': (context) => GeneratedhttpssyaluiuxblogspotcomWidget(),
        '/GeneratedhttpsakshaysyalwordpresscomcategoryfreebieWidget': (context) => GeneratedhttpsakshaysyalwordpresscomcategoryfreebieWidget(),
        '/GeneratedUIresourcesforyourbusinessWidget': (context) => GeneratedUIresourcesforyourbusinessWidget(),
        '/GeneratedGetmorefreebieitemsWidget': (context) => GeneratedGetmorefreebieitemsWidget(),
      },
    );
  }
}
